from __init__ import app
from controllers import users, posts

if __name__ == '__main__':
    app.run(debug=True)