package com.example.demo.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.models.Task;
import com.example.demo.services.TaskService;

@Controller
@RequestMapping("Task")
public class TaskController {

	@Autowired
	private TaskService service;
	
	@PostMapping("/add/{projectId}")
	public String add(
			@PathVariable Long projectId,
			@Valid @ModelAttribute("Task") Task task,
			BindingResult result,
			RedirectAttributes redirectAttributes
			) {
		
		if ( !result.hasErrors() ) {
			
			task = this.service.create(projectId, task);
			if ( task == null ) return "redirect:/";
			
			redirectAttributes.addFlashAttribute("message", "Your Task has been Added");
		}

		return String.format("redirect:/Project/update/%d", projectId);
	}
	
	@GetMapping("/delete/{id}")
	public String delete(
			@PathVariable Long id,
			RedirectAttributes redirectAttributes
			) {
		
		Task task = this.service.retrieve(id);
		
		if ( task == null ) return "redirect:/";
		
		this.service.delete(id);
		
		redirectAttributes.addFlashAttribute("message", "Your task has been deleted");
		
		return String.format("redirect:/project/update/%d", task.getProject().getId());
	}
}