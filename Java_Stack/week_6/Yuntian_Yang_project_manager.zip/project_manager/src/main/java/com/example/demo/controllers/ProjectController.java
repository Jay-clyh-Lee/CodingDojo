package com.example.demo.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.models.Project;
import com.example.demo.models.ProjectMember;
import com.example.demo.models.Task;
import com.example.demo.services.ProjectService;
import com.example.demo.services.MemberService;

@Controller
@RequestMapping("Project")
public class ProjectController {
	
	@Autowired
	private ProjectService service;
	
	@Autowired
	private MemberService MemberService;
	
	@GetMapping("/project/add")
	public String getAddForm(@ModelAttribute("project") Project project) {
		return "addProject.jsp";
	}
	
	@PostMapping("/project/add")
	public String add(
			@Valid @ModelAttribute("project") Project project,
			BindingResult result,
			RedirectAttributes redirectAttributes
			) {
		
		if ( result.hasErrors() ) return "addProject.jsp";
		
		this.service.create(project);
		
		redirectAttributes.addFlashAttribute("message", "Your project has been added");
		
		return "redirect:/";
	}
	
	@GetMapping("/project/{id}")
	public String ViewItem (@PathVariable Long id, Model model) {
		
		model.addAttribute("project", this.service.retrieve(id));
		
		return "viewProject.jsp";
	}
	
	@GetMapping("/project/delete/{id}")
	public String delete(
			@PathVariable Long id,
			RedirectAttributes redirectAttributes
			) {
		
		this.service.delete(id);
		
		redirectAttributes.addFlashAttribute("message", "Your project has been deleted");
		
		return "redirect:/";
	}
	
	@GetMapping("/project/update/{id}")
    public String getUpdateForm(Model model, @PathVariable Long id) {
		
			Project project = this.service.retrieve(id);
			
			if ( project == null ) return "redirect:/";
			
			model.addAttribute("project", project);
			model.addAttribute("task", new Task());
			
			if ( project.getProjectMember().size() > 0 ) {
				List<Long> excludeMembers = new ArrayList<Long>();
				
				for ( ProjectMember projectMember : project.getProjectMember() ) {
					excludeMembers.add(projectMember.getMember().getId());
				}
				
				model.addAttribute("Members", this.MemberService.allExcluding(excludeMembers));
			} else {
				model.addAttribute("Members", this.MemberService.all());
			}
			
            return "updateProject.jsp";
    }

	@PostMapping("/project/update")
	public String update(
			@Valid @ModelAttribute("project") Project project,
			BindingResult result,
			RedirectAttributes redirectAttributes) {
		
		if ( result.hasErrors() ) return "addProject.jsp";
		
//		Project ProjectToUpdate = this.service.retrieve(Project.getId());
//		
//		ProjectToUpdate.setTitle(Project.getTitle());
//		ProjectToUpdate.setMusician(Project.getMusician());
//		ProjectToUpdate.setYear(Project.getYear());
//		
//		ProjectToUpdate.getMetaData().setBitRate(bitrate);
//		ProjectToUpdate.getMetaData().setFormat(format);
		
		this.service.save(project);
		
		redirectAttributes.addFlashAttribute("message", "Your project has been updated");
		
		return "redirect:/";
	}
	
	@PostMapping("/attach-member/{projectId}")
	public String attachMember(
			@PathVariable Long projectId,
			@RequestParam(value="member_id") Long member_id,
			RedirectAttributes redirectAttributes
			) {
		
		if ( !this.service.attachMember(projectId, member_id) ) return "redirect:/";
		
		redirectAttributes.addFlashAttribute("message", "Member added");
		
		return String.format("redirect:/Project/update/%d", projectId);
	}
}