package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.models.ProjectMember;
import com.example.demo.repositories.ProjectMemberRepository;

@Service
public class ProjectMemberService {
	
	@Autowired
	private ProjectMemberRepository repository;
	
	public List<ProjectMember>all() {
		return this.repository.findAll();
	}
	
	public ProjectMember create(ProjectMember item) {
		return this.repository.save(item);
	}
	
	public void delete(Long itemId) {
		this.repository.deleteById(itemId);
	}
	
	public ProjectMember retrieve(Long itemId) {
		return this.repository.findById(itemId).get();
	}
	
	public ProjectMember save(ProjectMember item) {
		return this.repository.save(item);
	}
	
}