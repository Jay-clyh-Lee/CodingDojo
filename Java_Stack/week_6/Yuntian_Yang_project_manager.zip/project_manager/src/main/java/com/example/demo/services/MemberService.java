package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.models.Member;
import com.example.demo.repositories.MemberRepository;

@Service
public class MemberService {
	
	@Autowired
	private MemberRepository repository;
	
	public List<Member>all() {
		return this.repository.findAll();
	}
	
	public List<Member>allExcluding(List<Long> excludedMemberIds) {
		return this.repository.findByIdNotIn(excludedMemberIds);
	}
	
	public Member create(Member item) {
		return this.repository.save(item);
	}
	
	public void delete(Long itemId) {
		this.repository.deleteById(itemId);
	}
	
	public Member retrieve(Long itemId) {
		return this.repository.findById(itemId).get();
	}
	
	public Member save(Member item) {
		return this.repository.save(item);
	}
	
}