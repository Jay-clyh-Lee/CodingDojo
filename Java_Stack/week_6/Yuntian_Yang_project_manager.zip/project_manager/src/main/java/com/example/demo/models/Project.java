package com.example.demo.models;

import java.util.List;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
@Table(name="projects")
public class Project {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Size(min = 3, max = 50)
	private String name;
	
	@Size(min = 3, max = 50)
	private String lead;
	
	@NotEmpty(message="Due date cannot be empty.")
	private Date dueDate;

	@OneToMany(mappedBy="project", cascade=CascadeType.ALL, fetch=FetchType.LAZY)
	private List<ProjectMember> projectMember;
	
	@OneToMany(mappedBy="project", cascade=CascadeType.ALL, fetch=FetchType.LAZY)
	private List<Task> task;
	
	@Column(updatable=false)
	private Date createdAt;
	private Date updatedAt;
	
	@PrePersist
	protected void onCreate() {
	     this.createdAt = new Date();
	}

	@PreUpdate
	protected void onUpdate() {
		this.updatedAt = new Date();
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLead() {
		return lead;
	}

	public void setLead(String lead) {
		this.lead = lead;
	}

	public Date getdueDate() {
		return dueDate;
	}

	public void setdueDate(Date date) {
		this.dueDate = date;
	}

	public List<Task> getTask() {
		return task;
	}

	public List<ProjectMember> getProjectMember() {
		return projectMember;
	}

	public void setProjectMember(List<ProjectMember> projectMember) {
		this.projectMember = projectMember;
	}

	public void setTask(List<Task> task) {
		this.task = task;
	}

	public Project() {}
	
}