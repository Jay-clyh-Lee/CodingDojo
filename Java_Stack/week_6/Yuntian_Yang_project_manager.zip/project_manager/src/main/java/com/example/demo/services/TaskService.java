package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.models.Project;
import com.example.demo.models.Task;
import com.example.demo.repositories.TaskRepository;

@Service
public class TaskService {

	@Autowired
	private TaskRepository repository;
	
	@Autowired
	private ProjectService projectService;
	
	public List<Task>all() {
		return this.repository.findAll();
	}
	
	public Task create(Long projectId, Task item) {
		
		Project Project = this.projectService.retrieve(projectId);
		
		if ( Project == null ) return null;
		
		item.setProject(Project);
		
		return this.repository.save(item);
	}
	
	public void delete(Long itemId) {
		this.repository.deleteById(itemId);
	}
	
	public Task retrieve(Long itemId) {
		return this.repository.findById(itemId).get();
	}
	
	public Task save(Task item) {
		return this.repository.save(item);
	}
	
}