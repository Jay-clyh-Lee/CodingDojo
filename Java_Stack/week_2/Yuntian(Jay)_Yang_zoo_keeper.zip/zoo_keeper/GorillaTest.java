public class GorillaTest {
    public static void main(String[] args){
        Gorilla bigGeorge = new Gorilla();
        bigGeorge.displayEnergy();
        bigGeorge.throwSomething();
        bigGeorge.climb();
        bigGeorge.eatBananas();
        bigGeorge.displayEnergy();
    }
}
